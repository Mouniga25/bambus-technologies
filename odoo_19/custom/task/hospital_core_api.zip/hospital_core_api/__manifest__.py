{
    'name': 'Hospital Information System Integration',
    'version': '1.0',
    'summary': """hospital information system""",
    'description': """Hospital Information System Integration of the module""",
    'category': 'service',
    'author': 'Mouniga',
    'depends':['web','base',],
    'data':[
    	'security/ir.model.access.csv',

        'data/visit_sequence.xml',
          
        'views/hospital_department.xml',
        'views/hospital_diagnosis.xml',
        'views/hospital_doctor.xml',
        'views/hospital_lab_test.xml',
        'views/hospital_lab_result.xml',
        'views/hospital_patient_visit.xml',
        'views/hospital_prescription.xml',
        
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}