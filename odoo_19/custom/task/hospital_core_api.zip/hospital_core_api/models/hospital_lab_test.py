from odoo import api, fields, models
from datetime import datetime



class HospitalLabTest(models.Model):
    _name = 'hospital.lab.test'
    _description = "Hospital Lab Test"


    name  = fields.Char(string="Name")
    result = fields.Selection([('positive','Positive'),
                                ('negative','Negative')], string = "Result")
    description = fields.Char(string="Description")