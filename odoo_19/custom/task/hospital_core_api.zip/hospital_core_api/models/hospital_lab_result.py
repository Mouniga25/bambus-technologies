from odoo import api, fields, models
from datetime import datetime



class HospitalLabResult(models.Model):
    _name = 'hospital.lab.result'
    _description = "Hospital Lab Result"



    name = fields.Char(string="Name")
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    test_id = fields.Many2one('hospital.lab.test',string="test")
    patient_status = fields.Selection([('normal','Normal'),
                                ('low','Low'),
                                ('critical','Critical')], string ="Patient Status")
    test_date = fields.Date(string="Test_Date")
    price = fields.Float(string="Price")
    description = fields.Text(string="Description")