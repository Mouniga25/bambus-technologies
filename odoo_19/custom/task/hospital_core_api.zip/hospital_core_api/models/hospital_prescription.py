from odoo import api, fields, models
from datetime import datetime



class HospitalPrescription(models.Model):
    _name = 'hospital.prescription'
    _description = "Hospital Prescription"


    
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    med_name = fields.Char(string="medicine Name")
    timing = fields.Selection([('morning','Morning'),
                                ('afternoor','Afternoor'),
                                ('night','Night')])
    description = fields.Text(string="Description")
    visit_id = fields.Many2one("hospital.patient.visit","visit_number")
    
    notes = fields.Text(string="Notes")
    
    