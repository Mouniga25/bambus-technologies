from odoo import api, fields, models
from datetime import datetime



class HospitalPatientVisit(models.Model):
    _name = 'hospital.patient.visit'
    _description = "Hospital Patient Visit"
    _rec_name ="patient_name"

    #sequence
    visit_number = fields.Char(string="Reference",required=True, copy=False, readonly=True, default='New')
    

    #patient Detail
    patient_name = fields.Char(string="Patient Name", required=True)
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    department_id = fields.Many2one('hospital.department',string="Department")
    visit_date = fields.Datetime(string="Visit Date", required=True)
    symptoms = fields.Char(string="Symptoms", required=True)
    diagnosis_id = fields.Many2one('hospital.diagnosis',string="Diagnosis")
    prescription_id = fields.Many2one('hospital.prescription',string="Prescription")
    notes =  fields.Text(string="Notes", required=True)
    state = fields.Selection([('draft', 'Draft'), ('waiting', 'Waiting'),('consultation', 'Consultation'), ('lab_requested', 'Lab Requested'), ('completed', 'Completed'), ('cancelled', 'Cancelled') ], default="draft")



    """creating sequence number for the patient visit"""
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('visit_number','New') == 'New':
                vals['visit_number'] = self.env['ir.sequence'].next_by_code('hospital.patient.visit') or 'New'
        return super().create(vals_list)
    

    def action_draft(self):
        self.write({'state': 'draft'})
    def action_waiting(self):
        self.write({'state': 'waiting'})
    def action_consultation(self):
        self.write({'state': 'consultation'})
    def action_lab_requested(self):
        self.write({'state': 'lab_requested'})
    def action_completed(self):
        self.write({'state': 'completed'})
    def action_cancelled(self):
        self.write({'state': 'cancelled'})
    









     
    
    
     