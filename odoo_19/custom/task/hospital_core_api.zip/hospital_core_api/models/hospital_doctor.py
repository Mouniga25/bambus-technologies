from odoo import api, fields, models
from datetime import datetime



class HospitalDoctor(models.Model):
    _name = 'hospital.doctor'
    _description = "Hospital Doctor"
    _rec_name = "doctor_name"
    # _inherit = "contact.info"


    #doctor details
    doctor_name = fields.Char(string="Doctor Name")
    department_id = fields.Many2one('hospital.department',string="Department")
    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone")
    description = fields.Text(string="Description")
    # patient_lines = fields.One2many("res.partner","primary_doctor_id")


    