from odoo import api, fields, models, _, Command


class DepartmentInformation(models.Model):
    _name = 'department.information'
    _description = "department Information"
    
    name = fields.Char(string="Staff Name")
    department_id= fields.Integer(string="Staff Department")