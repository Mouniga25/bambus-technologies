from odoo import api, fields, models
from datetime import date

class StudentInformation(models.Model):
    _name = 'student.information'
    _description = "student information"

    name = fields.Char(string="Name")
    last_name=fields.Char(string="Last Name")
    semester= fields.Selection([('semester_1','Semester_1'),
                                ('semester_2','Semester_2'),
                                ('semester_3','Semester_3'),
                                ('semester_4','Semester_4'),
                                ('semester_5','Semester_5'),
                                ('semester_6','Semester_6')
                                ])

    date_of_birth = fields.Date(string="Date of Birth")
    age = fields.Integer(string="Age",
                         compute = "_compute_age",
                          store=True)
    
    department_id = fields.Many2one(
        'department.information',
        string="Department"
    )
    address = fields.Char(string="Address")
    email = fields.Char(string="Email")
    phone = fields.Integer(string="Phone")
    @api.depends('date_of_birth')
    def _compute_age(self):
        for record in self:
            if record.date_of_birth:
                today = date.today()
                record.age = today.year - record.date_of_birth.year
            else:
                record.age = 0