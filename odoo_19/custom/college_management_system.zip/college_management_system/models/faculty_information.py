from odoo import api, fields, models
from datetime import date

class FacultyInformation(models.Model):
    _name = 'faculty.information'
    _description = "faculty information"



    name = fields.Char(string="Name")
    last_name=fields.Char(string="Last Name")
    designation = fields.Selection([('principle','principle'),
                                    ('HOD','HOD'),
                                ('staff','Staff')])
    date_of_birth = fields.Date(string="Date of birth")
    age = fields.Integer(string="Age",
                         compute = "_compute_age",
                          store=True)
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    department_id = fields.Many2one(
        'department.information',
        string="Department"
    )
    degree_code = fields.Many2many(
        'degree.information',
        string="Degree"
    )
    graduation_institute = fields.Many2one(
        'graduation.institute',
        string="Graduation Institute"
    )
    address = fields.Char(string="Address")
    email = fields.Char(string="Email")
    phone = fields.Integer(string="Phone")
    @api.depends('date_of_birth')
    def _compute_age(self):
        for record in self:
            if record.date_of_birth:
                today = date.today()
                record.age = today.year - record.date_of_birth.year
            else:
                record.age = 0