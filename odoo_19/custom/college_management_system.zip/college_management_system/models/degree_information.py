from odoo import api, fields, models, _, Command


class DegreeInformation(models.Model):
    _name = 'degree.information'
    _description = "degree Information"
    
    name = fields.Char(string="Degree Name")
    degree_code= fields.Integer(string="Dgree Code")