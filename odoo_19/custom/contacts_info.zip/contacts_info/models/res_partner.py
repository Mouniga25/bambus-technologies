from odoo import api, fields, models
from datetime import datetime



class ContactsInfo(models.Model):
    _name = 'contact.info'
    _description = "Contacts Info"



    is_patient = fields.Boolean(string="Is Patient", required = True)
    patient_ID = fields.Char(string="Patient ID",required=True, copy=False, readonly=True, default='New')
    blood_group = fields.Selection([('o+','O+'),
                                ('a+','A+'),
                                ('b+','B+'),
                                ('ab-','AB-'),
                                ])
    date_of_Birth = fields.Date(string="Date of Birth")
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    height = fields.Float(string="Patient Name", required=True)
    weight = fields.Float(string="Patient Name", required=True)
    emergency_contact = fields.Char(string="Patient Name", required=True, size= 10)
    insurance_provider = fields.Text(string="Insurance Provider", required=True)
    insurance_number = fields.Char(string="Patient Name", required=True, size= 12)
    allergies = fields.Float(string="Patient Name", required=True)
    chronic_diseases = fields.Text(string="Chronic Diseases", required=True)
    # primary_doctor = fields.Many2one('hospital.doctor',string="Primary Doctor")
    last_visit_date = fields.Date(compute="_compute_last_visit",store=True)
    total_visits = fields.Char(compute="_compute_total_visits",store=True) 
    #total_lab_tests =
    #lab_results =
    #patient_visits =





