from odoo import api, fields, models, _, Command


class DegreeInformation(models.Model):
    _name = 'degree.information'
    _description = "degree Information"
    
    name = fields.Char(string="Degree Name")
    degree_code = fields.Integer(string="Degree Code")

    degree_lines = fields.One2many(comodel_name="degree.information.line", inverse_name = 'degree_id')




class DegreeInformationLine(models.Model):
    _name = 'degree.information.line'
    _description = 'Degree Information Line'


    degree_id = fields.Many2one(comodel_name='degree.information')

    name = fields.Char(string="Name")
    code = fields.Integer(string="Code")
    phone = fields.Char(string='Phone')





