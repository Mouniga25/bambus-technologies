from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError, ValidationError


class DepartmentInformation(models.Model):
    _name = 'department.information'
    _description = "department Information"
    _rec_name ="name"


    name = fields.Char(string="Staff Name")
    department_code= fields.Integer(string="Department Code")
    department_date = fields.Date(string=" Department Date")


    @api.onchange("name")
    def onchange_name(self):
        print(self,"------------")
        if self.name == "test":
            raise ValidationError("You can't give name as 'test'")
