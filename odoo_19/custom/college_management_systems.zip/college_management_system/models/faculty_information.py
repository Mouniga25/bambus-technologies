from odoo import api, fields, models
from datetime import date

class FacultyInformation(models.Model):
    _name = 'faculty.information'
    _description = "Faculty Information"



    name = fields.Char(string="Name")
    last_name=fields.Char(string="Last Name")
    designation = fields.Selection([('principle_college','Principle College'),
                                    ('hod','HOD'),
                                ('staff','Staff')])
    date_of_birth = fields.Date(string="Date of Birth")
    age = fields.Integer(string="Age",
                         compute = "_compute_age",
                          store=True)
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    photo = fields.Binary(string ="Image")

    are_you_human = fields.Boolean(string="are you human")

    department_id = fields.Many2one(
        'department.information',
        string="Department"
    )
    degree_ids = fields.Many2many(
        'degree.information',
        string="Degree"
    )
    graduation_institute_id = fields.Many2one(
        'graduation.institute',
        string="Graduation Institute"
    )
    total_degrees = fields.Integer(string = "Total Degree",
                                    compute = "_compute_total_degrees",
                                    store =False)
    address = fields.Char(string="Address")
    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone")
    publications = fields.Text(string="Publications")




    # calculate the age 
    @api.depends('date_of_birth')
    def _compute_age(self):
        for record in self:
            if record.date_of_birth:
                today = date.today()
                record.age = today.year - record.date_of_birth.year
            else:
                record.age = 0 

    #calculate the total number of degree
    # @api.depends('degree_ids')
    def _compute_total_degrees(self):
        # print(self,"-------------")
        for record in self:
            print(record,"---------record------------")
            record.total_degrees = len(record.degree_ids)













    
            

    

