from odoo import api, fields, models


class HospitalFollowupWizard(models.TransientModel):
    _name = 'hospital.followup.wizard'
    _description = "Hospital Followup Wizard"


    patient_id = fields.Many2one('res.partner',string="Patient ID", required=True,domain =[("is_patient", "=", True)])
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    appointment_date = fields.Datetime(string="Next Appointment", required=True)
    notes = fields.Text(string="Notes")

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        patient_id = self.env.context.get('active_id')

        if patient_id:
            patient = self.env['res.partner'].browse(patient_id)

            res.update({
                'degree_name': patient.patient_id,
         })
        return res


    