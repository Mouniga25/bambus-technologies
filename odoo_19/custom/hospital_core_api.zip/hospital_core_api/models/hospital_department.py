from odoo import api, fields, models
from datetime import datetime



class HospitalDepartment(models.Model):
    _name = 'hospital.department'
    _description = "Hospital Department"
    _rec_name = "department_name"


    department_name = fields.Char(string="Department Name", required=True)
    department_code = fields.Char(string="Department Code")

    # doctor_lines = fields.One2many("hospital.doctor","department_id", string="Doctors")


