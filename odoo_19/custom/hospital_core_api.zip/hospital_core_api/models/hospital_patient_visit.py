from odoo import api, fields, models
from datetime import datetime
from odoo.exceptions import ValidationError



class HospitalPatientVisit(models.Model):
    _name = 'hospital.patient.visit'
    _description = "Hospital Patient Visit"
    _rec_name ="patient_id"

    #sequence
    visit_number = fields.Char(string="Reference",required=True, copy=False, readonly=True, default='New')
    

    #patient Detail
    patient_id = fields.Many2one('res.partner',string="Patient ID", required=True,domain =[("is_patient", "=", True)])
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    department_id = fields.Many2one('hospital.department',string="Department", required=True)
    visit_date = fields.Datetime(string="Visit Date", required=True)
    symptoms = fields.Char(string="Symptoms", required=True)
    diagnosis_id = fields.Many2one('hospital.diagnosis',string="Diagnosis", required=True)
    prescription_id = fields.Many2one('hospital.prescription',string="Prescription", required=True)
    notes =  fields.Text(string="Notes", required=True)
    state = fields.Selection([('draft', 'Draft'), ('waiting', 'Waiting'),('consultation', 'Consultation'), ('lab_requested', 'Lab Requested'), ('completed', 'Completed'), ('cancelled', 'Cancelled') ], default="draft")



    """creating sequence number for the patient visit"""
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('visit_number','New') == 'New':
                vals['visit_number'] = self.env['ir.sequence'].next_by_code('hospital.patient.visit') or 'New'
        return super().create(vals_list)
    
#########
#ACTION
#########
    def action_draft(self):
        self.write({'state': 'draft'})
    def action_waiting(self):
        self.write({'state': 'waiting'})
    def action_consultation(self):
        self.write({'state': 'consultation'})
    def action_lab_requested(self):
        self.write({'state': 'lab_requested'})
    def action_completed(self):
        self.write({'state': 'completed'})
    def action_cancelled(self):
        self.write({'state': 'cancelled'})

    """Doctor name is requried"""
    @api.constrains("doctor_id")
    def _check_doctor(self):
        for rec in self:
            if not rec.doctor_id:
                raise ValidationError("Doctor is requried to fill")
    

    """Visiting date cannot be below Date of Birth"""
    @api.constrains("visit_date","patient_id")
    def _check_visiting_date(self):
        for rec in self:
            if rec.patient_id.date_of_birth and rec.visit_date:
                if rec.visit_date.date() < rec.patient_id.date_of_birth:
                    raise ValidationError("Visiting date cannot be below then Date of Birth")

    
    
            
    









     
    
    
     