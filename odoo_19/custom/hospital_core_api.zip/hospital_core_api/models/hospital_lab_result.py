from odoo import api, fields, models
from datetime import datetime
from odoo.exceptions import ValidationError



class HospitalLabResult(models.Model):
    _name = 'hospital.lab.result'
    _description = "Hospital Lab Result"


    Reference = fields.Char(string="Reference")
    patient_id = fields.Many2one('res.partner',string="Patient ID", required=True,domain =[("is_patient", "=", True)])
    doctor_id = fields.Many2one('hospital.doctor',string="Doctor Name")
    lab_test_id = fields.Many2one('hospital.lab.test',string="Lab Test")
    visit_id = fields.Many2one('hospital.patient.visit',string="Visit")
    test_id = fields.Many2one('hospital.lab.test',string="test")

    patient_status = fields.Selection([('normal','Normal'),
                                ('critical','Critical')], string ="Patient Status", default="normal")
    test_date = fields.Date(string="Test_Date")
    price = fields.Float(string="Price")
    description = fields.Text(string="Description")
    doctor_remark = fields.Text()
    result = fields.Float(string="Result")
    unit = fields.Char(string="Unit")
    Reference_range=fields.Char(string="Reference_range")
    # lab_results_lines = fields.One2many("hospital.lab.result","primary_doctor_id")
    # patient_visits_lines = fields.One2many("hospital.patient.visit","primary_doctor_id")

    """Future test date not allow"""
    @api.constrains("test.date")
    def _check_test_date(self):
        for rec in self:
            if rec.test.date and rec.test_date > date.today():
                raise ValidationError("Future test date is not allowed")
    
    """Negative Result validation"""
    @api.constrains("result")
    def _check_result(self):
        for rec in self:
            if rec.result < 0:
                raise ValidationError("Negative Result is not allowed")
    
    """Critical result must include doctor's remarks"""
    @api.constrains("patient_status","doctor_remark")
    def _check_remark(self):
        for rec in self:
            if rec.patient_status == "critical" and not rec.doctor_remark:
                raise ValidationError("Doctor remark are mandatory for the cirticel results")
    

    





