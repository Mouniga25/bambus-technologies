from odoo import api, fields, models
from datetime import date



class ContactsInfo(models.Model):
    _inherit = 'res.partner'



    is_patient = fields.Boolean(string="Is Patient", required = True)
    patient_id = fields.Char(string="Patient ID",required=True, copy=False, readonly=True, default='New')
    blood_group = fields.Selection([('o+','O+'),
                                ('a+','A+'),
                                ('b+','B+'),
                                ('ab-','AB-'),
                                ])
    
    date_of_birth = fields.Date(string="Date of Birth")
    age = fields.Integer(string ="Age", compute="_compute_age", store=True)
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    
    height = fields.Float(string="Height", required=True)
    weight = fields.Float(string="Weight", required=True)
    emergency_contact = fields.Char(string="Emergency Contact", required=True, size= 10)
    insurance_provider = fields.Text(string="Insurance Provider", required=True)
    insurance_number = fields.Char(string="Insurance Number", required=True, size= 12)
    allergies = fields.Text(string="Allergies", required=True)
    chronic_diseases = fields.Text(string="Chronic Diseases", required=True)
    primary_doctor_id = fields.Many2one('hospital.doctor',string="Primary Doctor")
    last_visit_date = fields.Date(string="Last Visit Date")

    # total_visits = fields.Char(compute="_compute_total_visits",store=True) 
    # total_lab_tests = fields.Char(compute="_compute_lab_test",store=True)

    total_visits =fields.Char(string="Total Visit")
    total_lab_tests = fields.Char(string = "Lab Test")
    visits_count = fields.Integer(compute="_compute_counts")
    lab_result_count = fields.Integer(compute="_compute_counts")
    prescription_count = fields.Integer(compute="_compute_counts")
    

    """creating sequence number for the patient visit"""
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('patient_id','New') == 'New':
                vals['patient_id'] = self.env['ir.sequence'].next_by_code('res.partner') or 'New'
        return super().create(vals_list)
    
    @api.depends('date_of_birth')
    def _compute_age(self):
        for rec in self:
            if rec.date_of_birth:
                today = date.today()
                rec.age = today.year - rec.date_of_birth.year
            else:
                rec.age = 0 
    #####
    # Smart button
    #####
    def action_view_visits(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Visits',
            'res_model': 'hospital.patient.visit',
            'view_mode': 'list,form',
            'domain': [('patient_id', '=', self.id)],
            }
    def action_view_lab_result(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Lab Result',
            'res_model': 'hospital.lab.result',
            'view_mode': 'list,form',
            'domain': [('patient_id', '=', self.id)],
            }
    def action_view_prescription(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Prescription',
            'res_model': 'hospital.prescription',
            'view_mode': 'list,form',
            'domain': [('patient_id', '=', self.id)],
            }
    def _compute_counts(self):
        Visit = self.env['hospital.patient.visit']
        Lab = self.env['hospital.lab.result']
        Prescription = self.env['hospital.prescription']

        for rec in self:
            rec.visits_count = Visit.search_count([('patient_id', '=', rec.id)])
            rec.lab_result_count = Lab.search_count([('patient_id', '=', rec.id)])
            rec.prescription_count = Prescription.search_count([('patient_id', '=', rec.id)])
    

class ContactsInfoLine(models.Model):
    _name = 'contacts.info.line'
    _description = 'Contacts Info'

    primary_doctor_id = fields.Many2one('hospital.doctor',string="Primary Doctor")




    

    





