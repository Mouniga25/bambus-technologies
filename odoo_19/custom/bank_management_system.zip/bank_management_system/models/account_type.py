from odoo import api, fields, models
from datetime import date

class AccountType(models.Model):
    _name = 'account.type'
    _description = "Account Type"
    _rec_name ="type_name"



    type_code = fields.Char(string="Type Code")
    type_name = fields.Selection([('savings','Savings'),
                                ('current','Current'),
                                ('fixed deposit','Fixed Deposit')
                                ])
    interest_rate = fields.Float(string="Interest Rate")




class AccountTypeLine(models.Model):
    _name = 'account.type.line'
    _description = 'Account Type Line'

    emp_id = fields.Many2one(comodel_name='employee.information')





