from odoo import api, fields, models
from datetime import date

class QualificationsInformation(models.Model):
    _name = 'qualifications.information'
    _description = "Qualifications Information"
    _rec_name ="qualifications_name"



    qualifications_code = fields.Char(string="Qualifications Code")
    qualifications_name = fields.Char(string="Qualifications Name")

