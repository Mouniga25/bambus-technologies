from odoo import api, fields, models
from datetime import date

class CustomerInformation(models.Model):
    _name = 'customer.information'
    _description = "Customer Information"



    name = fields.Char(string="Name")
    last_name=fields.Char(string="Last Name")
    photo = fields.Binary(string ="Image")
    kyc_status = fields.Selection([('pending','Pending'),
                                    ('verified','Verified'),
                                ('rejected','Rejected')])
    date_of_birth = fields.Date(string="Date of Birth")
    age = fields.Integer(string="Age")
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    
    home_branch_id = fields.Many2one(
        'branch.information',
        string="Home Branch"
    )
    customer_accounts_lines = fields.One2many(comodel_name="customer.information.line", 
                                     inverse_name = 'customer_id')
    

    nominee_details_lines = fields.One2many(comodel_name="customer.information.line", 
                                     inverse_name = 'customer_id')




class CustomerInformationLine(models.Model):
    _name = 'customer.information.line'
    _description = 'Customer Information Line'



    customer_id = fields.Many2one(comodel_name='customer.information')

    
    account_number = fields.Integer(string="Account Number")
    account_type = fields.Date(string="Account Type")
    current_balance = fields.Integer(string="Current Balance")
    status = fields.Char(string="Status")



    nominee_name = fields.Char(string="Nominee Name")
    relationship = fields.Selection([('spouse','Spouse'),
                                    ('child','Child'),
                                ('parent','Parent'),
                                ('other','Other')])
    share_percentage = fields.Float(string="share_percentage")
    phone = fields.Char(string="Phone")
    address = fields.Char(string="Addres")
    alternate_phone = fields.Char(string="Alternate Phone")




    




 
    



