from odoo import api, fields, models
from datetime import date

class BankAccount(models.Model):
    _name = 'bank.account'
    _description = "Bank Account"



    # customer_name_id = fields.Many2one(
    #     'customer.information.name',
    #     string="Customer Name"
    # )
    # account_type_id = fields.Many2one(
    #     'customer.information.account_type',
    #     string="Account Type"
    # )
    # home_branch = fields.Char(related ='home_branch_id')
    # opening_date = fields.Date(string="Opening Date")
    # account_status = fields.Selection([('active',' Active'),
    #                                 ('dormant','Dormant'),
    #                             ('closed','Closed')])
    
    





    
