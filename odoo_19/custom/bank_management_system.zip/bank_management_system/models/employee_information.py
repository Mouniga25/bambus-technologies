from odoo import api, fields, models
from datetime import date

class EmployeeInformation(models.Model):
    _name = 'employee.information'
    _description = "Employee Information"



    name = fields.Char(string="Name")
    last_name=fields.Char(string="Last Name")
    photo = fields.Binary(string ="Image")
    job_position = fields.Selection([('branch manager','Branch Manager'),
                                    ('teller','Teller'),
                                ('loan officer','Loan Officer'),
                                ('clerk','Clerk')])
    date_of_birth = fields.Date(string="Date of Birth")
    age = fields.Integer(string="Age")
    gender = fields.Selection([('female','Female'),
                                ('male','Male'),
                                ('other','Other')
                                ])
    branch_id = fields.Many2one(
        'branch.information',
        string="Branch"
    )
    qualifications_ids = fields.Many2many(
        'qualifications.information',
        string="Qualifications"
    )
    employee_lines = fields.One2many(comodel_name="employee.information.line", 
                                     inverse_name = 'employee_id')
    
    total_accounts_handled = fields.Integer(string="Total Accounts Handled",
                         compute = "_compute_total_accounts_handled",
                          store=True)
    

    account_lines = fields.One2many(comodel_name="account.type.line", 
                                     inverse_name = 'emp_id')
    
    """Calculate the total account handled"""
    def _compute_total_accounts_handled(self):
        for record in self:
            record.total_accounts_handled = len(record.account_ids)

   

class EmployeeInformationLine(models.Model):
    _name = 'employee.information.line'
    _description = 'Employee Information Line'

    employee_id = fields.Many2one(comodel_name='employee.information')

    
    dependent_name = fields.Char(string="Dependent Name")
    relationship = fields.Selection([('mother','Mother'),
                                    ('father','Father'),
                                ('brother','Brother'),
                                ('sister','Sister'),
                                ('husband','Husband'),
                                ('wife','Wife')])
    date_ofbirth = fields.Date(string="Date of Birth")
    ages = fields.Integer(string="Age",
                         compute = "_compute_ages",
                          store=True)
    

    address = fields.Char(string="Address")
    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone")
    hire_date = fields.Date(string="Hire Date")
    salary = fields.Float(string ="salary")
    access_level = fields.Selection([('level_1','Level 1'),
                                ('level_2','Level 2'),
                                ('level_3','Level 3')
                                ])
    

    """Onchange using age calculation"""
    @api.onchange('ages')
    def _onchange_ages(self):
        for record in self:
            if record.date_ofbirth:
                today = date.today()
                record.ages = today.year - record.date_ofbirth.year
            else:
                record.ages = 0
