{
    'name': 'Bank Management System',
    'version': '1.0',
    'summary': """Summary of the Module""",
    'description': """Description of the Module""",
    'category': 'service',
    'author': 'Mouniga',
    'depends':['web','base'],
    'data':[
    	'security/ir.model.access.csv',
        'views/employee_information.xml',
        'views/customer_information.xml',
        'views/branch_information.xml',
        'views/qualifications_information.xml',
        
        

    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}